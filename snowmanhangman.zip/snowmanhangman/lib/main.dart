import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sembast/sembast.dart';
import 'package:sembast_web/sembast_web.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 5), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey, // Change background color here
      body: Center(
        child: Image.asset(
          'assets/logo.jpg', // Replace with the path to your image asset
          width: 500,
          height: 500,
        ),
      ),
    );
  }
}

class LoginPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey, // Change background color here
        title: Text('Login'),
      ),
      body: LoginForm(),
    );
  }
}

class LoginForm extends StatefulWidget {
  @override
  _LoginFormState createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TextField(
            controller: _usernameController,
            decoration: InputDecoration(labelText: 'Username'),
            autofocus: false, // Disable autofocus for the TextField
          ),
          TextField(
            controller: _passwordController,
            decoration: InputDecoration(labelText: 'Password'),
            obscureText: true,
            autofocus: false, // Disable autofocus for the TextField
          ),
          SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () async {
              bool isAuthenticated = await authenticateUser(
                  _usernameController.text, _passwordController.text);
              if (isAuthenticated) {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SnowmanGame()),
                );
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Invalid username or password')));
              }
            },
            child: Text('Login'),
          ),
          SizedBox(height: 10.0),
          TextButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SignupPage()),
              );
            },
            child: Text('Create an account'),
          ),
        ],
      ),
    );
  }
}

class SignupPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.yellowAccent, // Change background color here
        title: Text('Sign Up'),
      ),
      body: SignupForm(),
    );
  }
}

class SignupForm extends StatefulWidget {
  @override
  _SignupFormState createState() => _SignupFormState();
}

class _SignupFormState extends State<SignupForm> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          TextField(
            controller: _usernameController,
            decoration: InputDecoration(labelText: 'Username'),
            autofocus: false, // Disable autofocus for the TextField
          ),
          TextField(
            controller: _passwordController,
            decoration: InputDecoration(labelText: 'Password'),
            obscureText: true,
            autofocus: false, // Disable autofocus for the TextField
          ),
          SizedBox(height: 20.0),
          ElevatedButton(
            onPressed: () async {
              await saveUser(
                  _usernameController.text, _passwordController.text);
              Navigator.pop(context);
            },
            child: Text('Sign Up'),
          ),
        ],
      ),
    );
  }
}

class SnowmanGame extends StatefulWidget {
  @override
  _SnowmanGameState createState() => _SnowmanGameState();
}

class _SnowmanGameState extends State<SnowmanGame> {
  final List<String> words = [
    'frostbite',
    'winter',
    'frost',
    'icehockey',
    'cold',
    'snowman',
    'chill',
    'white'
  ]; // Sample list of words
  final Map<String, String> hints = {
    'frostbite': 'when your body freezes due to cold',
    'winter': 'Coldest season of the year',
    'frost': 'Thin layer of ice crystals',
    'icehockey': 'sport played on Frozen water',
    'cold': 'Opposite of hot',
    'snowman': 'snow disguised as a person',
    'chill': 'A feeling of coldness in the air',
    'white': 'Color of snow'
  };

  late String hiddenWord;
  late String hint;
  late int wrongGuesses;
  late int winScore;
  late int lossScore;
  late List<String> guessedLetters;

  @override
  void initState() {
    super.initState();
    startGame();
    // Load win and loss scores
    loadScores();
  }

  void startGame() {
    final Random random = Random();
    final int randomIndex = random.nextInt(words.length);
    hiddenWord = words[randomIndex];
    hint = hints[hiddenWord]!;
    wrongGuesses = 0;
    guessedLetters = [];
  }

  void loadScores() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      winScore = prefs.getInt('win_score') ?? 0;
      lossScore = prefs.getInt('loss_score') ?? 0;
    });
  }

  void saveScores() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setInt('win_score', winScore);
    prefs.setInt('loss_score', lossScore);
  }

  bool isLetterGuessed(String letter) {
    return guessedLetters.contains(letter);
  }

  bool isGameWon() {
    return hiddenWord.split('').every((letter) => guessedLetters.contains(letter));
  }

  bool isGameLost() {
    return wrongGuesses >= 5;
  }

  void guessLetter(String letter) {
    if (!guessedLetters.contains(letter)) {
      setState(() {
        guessedLetters.add(letter);
        if (!hiddenWord.contains(letter)) {
          wrongGuesses++;
        }
      });
    }
  }

  void restartGame() {
    setState(() {
      startGame();
    });
  }

  void incrementWinScore() {
    setState(() {
      winScore++;
      saveScores();
    });
  }

  void incrementLossScore() {
    setState(() {
      lossScore++;
      saveScores();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey, // Change background color here
        title: Text('Ankit Snowman Game'),
        actions: [
          TextButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: Text('Scores'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Wins: $winScore'),
                      Text('Losses: $lossScore'),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text('Close'),
                    ),
                  ],
                ),
              );
            },
            child: Text('Scores'), // TextButton to show the scores
          ),
        ],
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/image${wrongGuesses}.jpg',
                width: 300,
                height: 300,
              ),
              SizedBox(height: 20),
              Text(
                'Hint: $hint',
                style: TextStyle(fontSize: 24),
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: hiddenWord.split('').map((letter) {
                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      isLetterGuessed(letter) ? letter : '_',
                      style: TextStyle(fontSize: 24),
                    ),
                  );
                }).toList(),
              ),
              SizedBox(height: 25),
              Wrap(
                spacing: 15,
                children: List.generate(26, (index) {
                  return ElevatedButton(
                    onPressed: isLetterGuessed(String.fromCharCode('a'.codeUnitAt(0) + index)) || isGameLost() || isGameWon() ? null : () => guessLetter(String.fromCharCode('a'.codeUnitAt(0) + index)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isLetterGuessed(String.fromCharCode('a'.codeUnitAt(0) + index)) ? Colors.blueGrey : Colors.blue, // Change the button color here
                    ),
                    child: Text(String.fromCharCode('a'.codeUnitAt(0) + index)),
                  );
                }),
              ),
              SizedBox(height: 20),
              isGameWon()
                  ? Column(
                children: [
                  Text(
                    'Congratulations! You won!',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      incrementWinScore();
                      restartGame();
                    },
                    child: Text('Play Again'),
                  ),
                ],
              )
                  : isGameLost()
                  ? Column(
                children: [
                  Text(
                    'Sorry, you lose!',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      incrementLossScore();
                      restartGame();
                    },
                    child: Text('Play Again'),
                  ),
                ],
              )
                  : Text(
                'Wrong guesses: $wrongGuesses',
                style: TextStyle(fontSize: 24),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Future<Database> openDB() async {
  return databaseFactoryWeb.openDatabase('user_database.db');
}

Future<void> saveUser(String username, String password) async {
  final Database db = await openDB();
  final store = intMapStoreFactory.store('users');
  await store.add(db, {'username': username, 'password': password});
}

Future<bool> authenticateUser(String username, String password) async {
  final Database db = await openDB();
  final store = intMapStoreFactory.store('users');
  final finder = Finder(filter: Filter.and([
    Filter.equals('username', username),
    Filter.equals('password', password),
  ]));
  final recordSnapshots = await store.find(db, finder: finder);
  return recordSnapshots.isNotEmpty;
}
