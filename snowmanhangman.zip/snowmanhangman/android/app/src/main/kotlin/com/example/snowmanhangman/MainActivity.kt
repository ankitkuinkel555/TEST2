package com.example.snowmanhangman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
